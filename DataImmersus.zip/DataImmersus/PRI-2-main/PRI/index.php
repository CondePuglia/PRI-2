<?php


header("Location: telas/inicio/inicio.php")
?>