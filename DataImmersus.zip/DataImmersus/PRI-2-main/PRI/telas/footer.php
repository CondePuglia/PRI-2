</div>
<div class="cd1">
    <footer class="py-3">
        <ul class="nav justify-content-center border-bottom pb-3 mb-3">
            <li class="nav-item"><a href="../inicio/inicio.php" class="nav-link px-2  text-white">Inicio</a></li>
            <li class="nav-item"><a href="../data/data.php" class="nav-link px-2 text-white" translate="no">Data</a></li>
            <li class="nav-item"><a href="../imer/immersus.php" class="nav-link px-2 text-white" translate="no">Immersus</a></li>
            <li class="nav-item"><a href="../sobre/projeto.php" class="nav-link px-2 text-white">Sobre</a></li>
        </ul>
        <p class="text-center text-white">© 2023 DATA IMMERSUS - Soares,Rafael & Puglia Conde,Ricardo</p>
    </footer>
</div>


<script src="https://cdnjs.cloudflare.com/ajax/libs/chroma-js/2.1.0/chroma.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
<script src="../script_global.js"></script>
<script src="js/script.js"></script>


</body>

</html>