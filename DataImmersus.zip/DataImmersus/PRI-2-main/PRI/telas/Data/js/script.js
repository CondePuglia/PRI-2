var mudarcor = document.querySelector("#body");

mudarcor.classList.remove("cp1");
mudarcor.classList.add("bg-body"); 