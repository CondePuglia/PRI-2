<?php

require "../header.php";

require "../menu.php";
?>
<div class="container" id="inicio">
    <section class="section-1">

    <img src="../login/img/undraw_access_account_re_8spm.svg" alt="">

    
    </section>


</div>


<?php
require "../footer.php"
?>