package br.com.dataimmersus.dao;

import br.com.dataimmersus.dto.UsuarioDTO;
import java.sql.*;

public class UsuarioDAO {

    public UsuarioDAO() {
    }

    private ResultSet rs = null;

    private Statement stmt = null;

    public boolean inserirUsuario(UsuarioDTO usuarioDTO) {
        try {
            ConexaoDAO.ConectDB();

            stmt = ConexaoDAO.con.createStatement();

            String comando = "Insert into usuario(name,email,password) values ("
                    + "'" + usuarioDTO.getName() + "', "
                    + "'" + usuarioDTO.getEmail() + "',"
                    + "'" + usuarioDTO.getPassword() + "')";

            stmt.execute(comando);

            ConexaoDAO.con.commit();

            stmt.close();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        } finally {
            ConexaoDAO.CloseDB();
        }
    }//Fecha método inserirUsuario

    public boolean excluirUsuario(UsuarioDTO usuarioDTO) {
        try {
            //Chama o metodo que esta na classe ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConectDB();
            //Cria o Statement que responsavel por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //Comando SQL que sera executado no banco de dados
            String comando = "Delete from usuario where CodUsu = " + usuarioDTO.getCodUsu();

            //Executa o comando SQL no banco de Dados
            stmt.execute(comando);
            //Da um commit no banco de dados
            ConexaoDAO.con.commit();
            //Fecha o statement
            stmt.close();
            return true;
        } //Caso tenha algum erro no codigo acima é enviado uma mensagem no console com o que esta acontecendo.
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        } //Independente de dar erro ou não ele vai fechar o banco de dados.
        finally {
            //Chama o metodo da classe ConexaoDAO para fechar o banco de dados
            ConexaoDAO.CloseDB();
        }
    }

    public boolean alterarUsuario(UsuarioDTO usuarioDTO) {
        try {
            //Chama o metodo que esta na classe ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConectDB();
            //Cria o Statement que responsavel por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //Comando SQL que sera executado no banco de dados
            String comando = "Update usuario set "
                    + "name = '" + usuarioDTO.getName() + "', "
                    + "email = '" + usuarioDTO.getEmail() + "', "
                    + "password = '" + usuarioDTO.getPassword() + "' "
                    + "where CodUsu = " + usuarioDTO.getCodUsu();

            //Executa o comando SQL no banco de Dados
            stmt.execute(comando.toUpperCase());
            //Da um commit no banco de dados
            ConexaoDAO.con.commit();
            //Fecha o statement
            stmt.close();
            return true;
        } //Caso tenha algum erro no codigo acima é enviado uma mensagem no console com o que esta acontecendo.
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        } //Independente de dar erro ou não ele vai fechar o banco de dados.
        finally {
            //Chama o metodo da classe ConexaoDAO para fechar o banco de dados
            ConexaoDAO.CloseDB();
        }
    }
    public ResultSet consultarUsuario(UsuarioDTO usuarioDTO, int opcao) {
        try {
            //Chama o metodo que esta na classe ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConectDB();
            //Cria o Statement que responsavel por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //Comando SQL que sera executado no banco de dados
            String comando = "";
            switch (opcao){
                case 1:
                    comando = "Select u.* "+
                              "from usuario u "+
                              "where name like '" + usuarioDTO.getName() + "%' " +
                              "order by u.name";
                    
                break;
                case 2:
                    comando = "Select u.* "+
                              "from usuario u " +
                              "where u.CodUsu = " + usuarioDTO.getCodUsu();
                break;
                case 3:
                    comando = "Select u.CodUsu, u.name "+
                              "from usuario u ";
                break;
                
            }
            //Executa o comando SQL no banco de Dados
            rs = stmt.executeQuery(comando);
            return rs;
        } //Caso tenha algum erro no codigo acima é enviado uma mensagem no console com o que esta acontecendo.
        catch (Exception e) {
            System.out.println(e.getMessage());
            return rs;
        }
    }
}//Esta chave fecha a classe

