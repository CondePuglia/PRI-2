<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <meta http-equiv="refresh" content="60">
</head>
<body>
<div id="resultContainer"></div>
<script type="module"  src="script_fire_1.js"></script>
    <?php
    
   
    require '../../../conexao.php';
 $receivedUmi = $_POST['Umi'];
 $receivedLumi = $_POST['Lumi'];
 $receivedTemp = $_POST['Temp'];
 $receivedDate = $_POST['Date'];
 $CodSen = $_POST['CodSen'];;
 if (isset($_POST['Umi']) && isset($_POST['Lumi']) && isset($_POST['Temp'])) {
    
   
        echo 'Received Umi in PHP: ' . $receivedUmi . '<br>';
        echo 'Received Lumi in PHP: ' . $receivedLumi . '<br>';
        echo 'Received Temp in PHP: ' . $receivedTemp . '<br>';
        echo 'Received Data in PHP: ' . $receivedDate . '<br>';
        echo 'Received Cod in PHP: ' .  $CodSen . '<br>';

        $sql = "INSERT INTO dados_ambiente ( CodSen, ValorLumi, ValorUmi, ValorTemp, DataCaptura) VALUES ( ?, ?, ?, ?, ?)";

        try {
            $stmt = $conn->prepare($sql);
            $result = $stmt->execute([$CodSen, $receivedLumi, $receivedUmi, $receivedTemp,$receivedDate]);
        } catch (Exception $e) {
            $result = false;
            $error = $e->getMessage();
        }
        
        if ($result == true) {
            $_SESSION["result"] = true;
        }
        
    } 
    ?>
</body>
</html>