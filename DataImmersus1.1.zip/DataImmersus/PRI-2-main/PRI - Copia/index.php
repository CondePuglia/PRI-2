<?php


header("Location: Telas/Login/login.php")
?>