/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.dataimmersus.ctr;

import br.com.dataimmersus.dao.ConexaoDAO;
import br.com.dataimmersus.dao.LocalDAO;
import br.com.dataimmersus.dao.UsuarioDAO;
import br.com.dataimmersus.dto.LocalDTO;
import br.com.dataimmersus.dto.UsuarioDTO;
import java.sql.ResultSet;

/**
 *
 * @author Aluno
 */
public class LocalCTR {
      LocalDAO localDAO = new LocalDAO();
      UsuarioDAO usuarioDAO = new UsuarioDAO();
    public LocalCTR() {

    }

    public String inserirLocal(LocalDTO localDTO) {
        try {
            if (localDAO.inserirLocal(localDTO)) {
                return "Local Cadastrado Com Sucesso";
            } else {
                return "Local NÃO Cadastrado";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "Local NÃO Cadastro";
        }
    }//Fecha o método inserirUsuario

  //  public String alterarLocal(LocalDTO localDTO) {
  //      try {
  //          if (localDAO.alterarLocal(localDTO)) {
   //             return "Local Alterado Com Sucesso";
    //        } else {
     //           return "Local NÃO Alterado";
      //      }
       // } catch (Exception e) {
        //    System.out.println(e.getMessage());
         //   return "Usuario NÃO Alterado";
       // }
   // }//Fecha o método alterarUsuario

    public String excluirLocal(LocalDTO localDTO) {
        try {
            if (localDAO.excluirLocal(localDTO)) {
                return "Local Excluido Com Sucesso";
            } else {
                return "Local NÃO Excluido";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "Local NÃO Excluido";
        }
    }

  public ResultSet consultarLocal(LocalDTO localDTO,UsuarioDTO usuarioDTO, int opcao) {
        //É criado um atributo do tipo ResultSet, pois este método recebe o resultado de uma consulta.
        ResultSet rs = null;

        //O atributo rs recebe a consulta realizada pelo método da classe DAO
        rs = localDAO.consultarLocal(localDTO,usuarioDTO,opcao);

        return rs;
    }
   
    public void CloseDB(){
        ConexaoDAO.CloseDB();
    }
     
}
