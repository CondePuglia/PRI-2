package br.com.dataimmersus.ctr;

import br.com.dataimmersus.dao.ConexaoDAO;
import br.com.dataimmersus.dao.DadosDAO;
import br.com.dataimmersus.dao.LocalDAO;
import br.com.dataimmersus.dao.UsuarioDAO;
import br.com.dataimmersus.dto.DadosDTO;
import br.com.dataimmersus.dto.LocalDTO;
import br.com.dataimmersus.dto.UsuarioDTO;
import java.sql.ResultSet;

/**
 *
 * @author Aluno
 */
public class DadosCTR {
      LocalDAO localDAO = new LocalDAO();
      UsuarioDAO usuarioDAO = new UsuarioDAO();
       DadosDAO dadosDAO = new DadosDAO();

    public ResultSet consultarDados(LocalDTO localDTO,UsuarioDTO usuarioDTO, int opcao) {
        //É criado um atributo do tipo ResultSet, pois este método recebe o resultado de uma consulta.
        ResultSet rs = null;

        //O atributo rs recebe a consulta realizada pelo método da classe DAO
        rs = dadosDAO.consultarDados(localDTO,usuarioDTO,3);

        return rs;
    }
     public String excluirDados(LocalDTO localDTO, DadosDTO dadosDTO) {
        try {
            if (localDAO.excluirLocal(localDTO)) {
                return "Dados Excluido Com Sucesso";
            } else {
                return "Dados NÃO Excluidos";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "Dados NÃO Excluido";
        }
    }
   
    public void CloseDB(){
        ConexaoDAO.CloseDB();
    }
}