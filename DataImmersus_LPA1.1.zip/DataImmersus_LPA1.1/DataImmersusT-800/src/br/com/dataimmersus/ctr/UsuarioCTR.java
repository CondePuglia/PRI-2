package br.com.dataimmersus.ctr;

import java.sql.ResultSet;
import br.com.dataimmersus.dto.UsuarioDTO;
import br.com.dataimmersus.dao.UsuarioDAO;
import br.com.dataimmersus.dao.ConexaoDAO;

public class UsuarioCTR {

    UsuarioDAO usuarioDAO = new UsuarioDAO();

    public UsuarioCTR() {

    }

    public String inserirUsuario(UsuarioDTO usuarioDTO) {
        try {
            if (usuarioDAO.inserirUsuario(usuarioDTO)) {
                return "Usuario Cadastrado Com Sucesso";
            } else {
                return "Usuario NÃO Cadastrado";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "Usuario NÃO Cadastro";
        }
    }//Fecha o método inserirUsuario

    public String alterarUsuario(UsuarioDTO usuarioDTO) {
        try {
            if (usuarioDAO.alterarUsuario(usuarioDTO)) {
                return "Usuario Alterado Com Sucesso";
            } else {
                return "Usuario NÃO Alterado";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "Usuario NÃO Alterado";
        }
    }//Fecha o método alterarUsuario

    public String excluirUsuario(UsuarioDTO usuarioDTO) {
        try {
            if (usuarioDAO.alterarUsuario(usuarioDTO)) {
                return "Usuario Excluido Com Sucesso";
            } else {
                return "Usuario NÃO Excluido";
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return "Usuario NÃO Excluido";
        }
    }

    public ResultSet consultarUsuario(UsuarioDTO usuarioDTO, int opcao) {
        ResultSet rs = null;

        rs = usuarioDAO.consultarUsuario(usuarioDTO, opcao);

        return rs;
    }//Fecha o método consultarUsuario
    public int logarUsuario(UsuarioDTO usuarioDTO) {
        
        return usuarioDAO.logarUsuario(usuarioDTO);

    }
    public void CloseDB(){
        ConexaoDAO.CloseDB();
    }
    
}//Fecha Classe UsuarioCTR
