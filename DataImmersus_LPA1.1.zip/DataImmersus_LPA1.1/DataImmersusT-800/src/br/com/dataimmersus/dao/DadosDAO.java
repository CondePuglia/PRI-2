package br.com.dataimmersus.dao;

import br.com.dataimmersus.dto.DadosDTO;
import br.com.dataimmersus.dto.LocalDTO;
import br.com.dataimmersus.dto.UsuarioDTO;
import java.sql.*;



public class DadosDAO {
 
    private ResultSet rs = null;

    private Statement stmt = null;
    
    
    
    public ResultSet consultarDados(LocalDTO localDTO,UsuarioDTO usuarioDTO, int opcao) {
        try {
            //Chama o metodo que esta na classe ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConectDB();
            //Cria o Statement que responsavel por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //Comando SQL que sera executado no banco de dados
            String comando = "";
            switch (opcao) {
                case 1:
                  //  comando = "Select l.* "
                  //          + "from local l "
                 //           + "where NameLocal like '" + localDTO.getNameLocal() + "%' "
                 //           + "order by l.NameLocal";

                    break;
                case 2:
                    comando = "Select l.* "
                            + "from local l "
                            + "where l.CodSen = " + localDTO.getCodSen();
                    break;
                case 3:
                    comando = "Select l.DataCaptura,l.ValorUmi,l.ValorLumi,l.ValorTemp "
                            + "from dados_ambiente l "
                            + "where CodSen=" 
                            + localDTO.getCodSen()
                            ;
                    break;
                    
                case 4:
                    comando = "Select l.* "
                            + "from local l "
                            + "order by l.NameLocal";

            }
            //Executa o comando SQL no banco de Dados
            rs = stmt.executeQuery(comando);
            return rs;
        } //Caso tenha algum erro no codigo acima é enviado uma mensagem no console com o que esta acontecendo.
        catch (Exception e) {
            System.out.println(e.getMessage());
            return rs;
        }
    }
    
     public boolean excluirDados(LocalDTO localDTO, DadosDTO dadosDTO) {
        try {
            //Chama o metodo que esta na classe ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConectDB();
           
            //Cria o Statement que responsavel por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //Comando SQL que sera executado no banco de dados
            String comando = "Delete * from dados_ambiente where CodSen = " + localDTO.getCodSen();
            System.out.println("3");
            //Executa o comando SQL no banco de Dados
            stmt.execute(comando);
            System.out.println("4");
            //Da um commit no banco de dados
            ConexaoDAO.con.commit();
            //Fecha o statement
            stmt.close();
            return true;
        } //Caso tenha algum erro no codigo acima é enviado uma mensagem no console com o que esta acontecendo.
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        } //Independente de dar erro ou não ele vai fechar o banco de dados.
        finally {
            //Chama o metodo da classe ConexaoDAO para fechar o banco de dados
            ConexaoDAO.CloseDB();
        }
    }
    
}

