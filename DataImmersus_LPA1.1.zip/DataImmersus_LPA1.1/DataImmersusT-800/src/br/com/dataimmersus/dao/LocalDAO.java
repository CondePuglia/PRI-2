package br.com.dataimmersus.dao;

import br.com.dataimmersus.dto.LocalDTO;
import br.com.dataimmersus.dto.UsuarioDTO;
import java.sql.*;

public class LocalDAO {
     UsuarioDTO usuarioDTO = new UsuarioDTO();  
    private ResultSet rs = null;

    private Statement stmt = null;

    public boolean inserirLocal(LocalDTO localDTO) {
        try {
            ConexaoDAO.ConectDB();
           
            stmt = ConexaoDAO.con.createStatement();

            String comando = "Insert into local(CodUsu,NameLocal) values ("
                    + " " + localDTO.getCodUsu() + ","
                    + "'" + localDTO.getNameLocal() + "')";
            System.out.println(comando);
            stmt.execute(comando);

            ConexaoDAO.con.commit();

            stmt.close();
            return true;
        } catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        } finally {
            ConexaoDAO.CloseDB();
        }
    }//Fecha método inserirUsuario

    public boolean excluirLocal(LocalDTO localDTO) {
        try {
            //Chama o metodo que esta na classe ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConectDB();
            //Cria o Statement que responsavel por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //Comando SQL que sera executado no banco de dados
            String comando1 = "Delete from dados_ambiente where CodSen = " + localDTO.getCodSen();
            String comando = "Delete from local where CodSen = " + localDTO.getCodSen();
        
            //Executa o comando SQL no banco de Dados
            stmt.execute(comando1);
                System.out.println("1");
              stmt.execute(comando);
            System.out.println("2");
            //Da um commit no banco de dados
            ConexaoDAO.con.commit();
            //Fecha o statement
            stmt.close();
            return true;
        } //Caso tenha algum erro no codigo acima é enviado uma mensagem no console com o que esta acontecendo.
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        } //Independente de dar erro ou não ele vai fechar o banco de dados.
        finally {
            //Chama o metodo da classe ConexaoDAO para fechar o banco de dados
            ConexaoDAO.CloseDB();
        }
    }

    public boolean alterarLocal(LocalDTO localDTO) {
        try {
            //Chama o metodo que esta na classe ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConectDB();
            //Cria o Statement que responsavel por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //Comando SQL que sera executado no banco de dados
            String comando = "Update local set NameLocal= '"
                    + localDTO.getNameLocal() + "'"
                    + "where CodSen =" + localDTO.getCodSen()
                    + " ";

            //Executa o comando SQL no banco de Dados
            stmt.execute(comando.toUpperCase());
            //Da um commit no banco de dados
            ConexaoDAO.con.commit();
            //Fecha o statement
            stmt.close();
            return true;
        } //Caso tenha algum erro no codigo acima é enviado uma mensagem no console com o que esta acontecendo.
        catch (Exception e) {
            System.out.println(e.getMessage());
            return false;
        } //Independente de dar erro ou não ele vai fechar o banco de dados.
        finally {
            //Chama o metodo da classe ConexaoDAO para fechar o banco de dados
            ConexaoDAO.CloseDB();
        }
    }

    public ResultSet consultarLocal(LocalDTO localDTO,UsuarioDTO usuarioDTO, int opcao) {
        try {
            //Chama o metodo que esta na classe ConexaoDAO para abrir o banco de dados
            ConexaoDAO.ConectDB();
            //Cria o Statement que responsavel por executar alguma coisa no banco de dados
            stmt = ConexaoDAO.con.createStatement();
            //Comando SQL que sera executado no banco de dados
            String comando = "";
            switch (opcao) {
                case 1:
                    comando = "Select l.* "
                            + "from local l "
                            + "where NameLocal like '" + localDTO.getNameLocal() + "%' "
                            + "order by l.NameLocal";

                    break;
                case 2:
                    comando = "Select l.* "
                            + "from local l "
                            + "where l.CodSen = " + localDTO.getCodSen();
                    break;
                case 3:
                    comando = "Select l.CodSen, l.NameLocal "
                            + "from local l ";
                    break;

                case 4:
                    comando = "select CodSen,namelocal from local l "
                            + " inner join usuario u"
                            + " on u.CodUsu = l.CodUsu"
                            + " where l.CodUsu = " 
                            + usuarioDTO.getCodUsu();
                break;           

            }
            //Executa o comando SQL no banco de Dados
            rs = stmt.executeQuery(comando);
            return rs;
        } //Caso tenha algum erro no codigo acima é enviado uma mensagem no console com o que esta acontecendo.
        catch (Exception e) {
            System.out.println(e.getMessage());
            return rs;
        }
    }
}
