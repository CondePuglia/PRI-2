package br.com.dataimmersus.dto;

public class LocalDTO {

    public int getCodSen() {
        return CodSen;
    }

    public void setCodSen(int CodSen) {
        this.CodSen = CodSen;
    }

    public int getCodUsu() {
        return CodUsu;
    }

    public void setCodUsu(int CodUsu) {
        this.CodUsu = CodUsu;
    }

    public String getNameLocal() {
        return NameLocal;
    }

    public void setNameLocal(String NameLocal) {
        this.NameLocal = NameLocal;
    }
    private int CodSen, CodUsu;
    private String NameLocal;
}
