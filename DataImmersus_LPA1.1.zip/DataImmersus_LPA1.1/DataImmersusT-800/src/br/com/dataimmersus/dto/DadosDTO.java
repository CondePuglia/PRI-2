package br.com.dataimmersus.dto;

/**
 *
 * @author Aluno
 */
public class DadosDTO {

    public int getIdDadosAmb() {
        return idDadosAmb;
    }

    public void setIdDadosAmb(int idDadosAmb) {
        this.idDadosAmb = idDadosAmb;
    }

    public int getCodSen() {
        return CodSen;
    }

    public void setCodSen(int CodSen) {
        this.CodSen = CodSen;
    }

    public float getValorLumi() {
        return ValorLumi;
    }

    public void setValorLumi(float ValorLumi) {
        this.ValorLumi = ValorLumi;
    }

    public float getValorUmi() {
        return ValorUmi;
    }

    public void setValorUmi(float ValorUmi) {
        this.ValorUmi = ValorUmi;
    }

    public float getValorTemp() {
        return ValorTemp;
    }

    public void setValorTemp(float ValorTemp) {
        this.ValorTemp = ValorTemp;
    }

    public String getDataCaptura() {
        return DataCaptura;
    }

    public void setDataCaptura(String DataCaptura) {
        this.DataCaptura = DataCaptura;
    }
    private int  idDadosAmb, CodSen;
    private float ValorLumi, ValorUmi, ValorTemp;
    private String DataCaptura;
}
